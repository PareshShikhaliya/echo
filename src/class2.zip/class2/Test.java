package class2;

public class Test {
    public static void main(String[] args)
    {
        String name = "ViratKohli";
        System.out.println( name.substring(3,6));

    }
}
