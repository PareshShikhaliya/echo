package class2;

public class HelloWorldProgram12 {
    public static void main(String[] args) {
        /*
        System is a pre-defined class in Java.
        out is a static member of the System class that represents the standard output stream, which is typically the console.
        println() is a method of the PrintStream class, which is the type of the out stream. It is used to print a line of text to the output stream.
         */
        System.out.println("Hello");
    }
}
