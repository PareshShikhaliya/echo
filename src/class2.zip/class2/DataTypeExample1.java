package class2;

public class DataTypeExample1 {
    public static void main(String[] args) {
        boolean isRaining = true;
        byte age = 25;
        short year = 2023;
        int population = 789456123;
        long distance = 1500000000L;
        char grade = 'A';
        float temperature = 25.5f;
        double pi = 3.14159;

        System.out.println("Is it raining? " + isRaining);
        System.out.println("Age: " + age);
        System.out.println("Year: " + year);
        System.out.println("Population: " + population);
        System.out.println("Distance: " + distance);
        System.out.println("Grade: " + grade);
        System.out.println("Temperature: " + temperature);
        System.out.println("Pi: " + pi);
    }
}
